mkdir customer_segmentation_1.csv{1..50}
mkdir user_activity_.json{1..50}
