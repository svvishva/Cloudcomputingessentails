#!/bin/bash

# Check if a directory is passed as an argument
if [ -z "$1" ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

# The directory to clean
DIR="$1"

# Check if the directory exists
if [ ! -d "$DIR" ]; then
    echo "Error: $DIR does not exist."
    exit 1
fi

# Find and delete all empty subdirectories
find "$DIR" -type d -empty -delete

# Output confirmation
echo "All empty directories within '$DIR' have been deleted."
